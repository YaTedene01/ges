<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erreur interne du serveur</title>
</head>
<body>
    <h1>500 - Erreur interne du serveur</h1>
    <p>Une erreur inattendue s'est produite. Veuillez réessayer plus tard.</p>
</body>
</html>