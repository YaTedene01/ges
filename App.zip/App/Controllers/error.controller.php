<?php
return [
    'required_field' => 'Tous les champs sont obligatoires',
    'invalid_credentials' => 'Identifiants incorrects',
    'invalid_user_data' => 'Données utilisateur invalides',
    
];