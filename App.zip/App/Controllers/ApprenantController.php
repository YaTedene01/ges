<?php
namespace App\Controllers;

// Importer les contrôleurs existants qui contiennent les fonctions dont nous avons besoin
require_once __DIR__ . '/PromoController.php'; // Pour get_all_promotions()
require_once __DIR__ . '/controller.php'; // Pour la fonction redirect()

// Fonction pour récupérer tous les référentiels (si elle n'existe pas ailleurs)
function get_all_referentiels() {
    // Implémentation temporaire - retourne un tableau vide
    // À remplacer par votre logique de récupération des référentiels depuis la base de données
    return [];
}

// Fonction pour afficher le formulaire d'ajout d'apprenant
function show_create_form() {
    // Charger les promotions et référentiels pour les listes déroulantes
    $promotions = get_all_promotions(); // Cette fonction est importée de PromoController.php
    $referentiels = get_all_referentiels();
    
    // Modifier cette ligne pour pointer vers le bon fichier
    require __DIR__ . '/../Views/Apprenants/ajoutapprenant.php';
}

// Fonction pour créer un apprenant
function create_apprenant() {
    // Vérifier si le formulaire a été soumis
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create') {
        // Charger les messages d'erreur
        $error_messages = include __DIR__ . '/../lang/error.fr.php';
        $errors = [];
        
        // Validation des champs
        if (empty($_POST['nom'])) {
            $errors['nom'] = $error_messages['apprenant']['nom_required'];
        }
        
        if (empty($_POST['prenom'])) {
            $errors['prenom'] = $error_messages['apprenant']['prenom_required'];
        }
        
        if (empty($_POST['email'])) {
            $errors['email'] = $error_messages['apprenant']['email_required'];
        } elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = $error_messages['apprenant']['email_invalid'];
        }
        
        if (empty($_POST['telephone'])) {
            $errors['telephone'] = $error_messages['apprenant']['telephone_required'];
        } elseif (!preg_match('/^[0-9]{9,15}$/', preg_replace('/[^0-9]/', '', $_POST['telephone']))) {
            $errors['telephone'] = $error_messages['apprenant']['telephone_invalid'];
        }
        
        if (empty($_POST['date_naissance'])) {
            $errors['date_naissance'] = $error_messages['apprenant']['date_naissance_required'];
        }
        
        if (empty($_POST['promotion'])) {
            $errors['promotion'] = $error_messages['apprenant']['promotion_required'];
        }
        
        if (empty($_POST['referentiel'])) {
            $errors['referentiel'] = $error_messages['apprenant']['referentiel_required'];
        }
        
        if (empty($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
            $errors['photo'] = $error_messages['apprenant']['photo_required'];
        }
        
        // S'il y a des erreurs
        if (!empty($errors)) {
            // Stocker les erreurs et les anciennes valeurs en session
            session_set('apprenant_errors', $errors);
            session_set('old_input', $_POST);
            
            // Rediriger vers le formulaire
            redirect('/apprenants/create');
            exit;
        }
        
        // Si pas d'erreurs, traiter le formulaire
        // ... code pour créer l'apprenant ...
        
        // Rediriger avec un message de succès
        session_set('success_message', ['content' => 'Apprenant ajouté avec succès']);
        redirect('/apprenants');
        exit;
    }
    
    // Si ce n'est pas une soumission de formulaire, afficher le formulaire
    show_create_form();
}
