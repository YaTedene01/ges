<?php
// message.fr.php content


return [
    // Messages de succès
    SuccessCode::PROMOTION_CREATED->value => 'Promotion créée avec succès',
    SuccessCode::PROMOTION_UPDATED->value => 'Promotion mise à jour avec succès'
];