<?php
//urls.php

define('APP_BASE_URL', 'http://faye.yatedene.sa.edu.sn:8031');

return [
    'promotions' => APP_BASE_URL . '/promotions',
    'promotions_create' => APP_BASE_URL . '/promotions/create',
    'promotion_modal' => APP_BASE_URL . '/promotions#promotionModal'
];